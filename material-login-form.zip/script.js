function login() {
    alert('Login button clicked!');
}